<?php
session_start();
unset($_SESSION['g_id']);
unset($_SESSION['NAME']);
?>