<?php


define('DB_HOST', 'localhost');
define('DB_USER', 'u430585285_hostel');
define('DB_PASSWORD', 'Bhavesh*123');
define('DB_NAME', 'u430585285_hostel');
